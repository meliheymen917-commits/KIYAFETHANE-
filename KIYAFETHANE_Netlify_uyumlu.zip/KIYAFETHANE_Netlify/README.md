# KIYAFETHANE
1. Supabase projesi açıp `supabase/schema.sql` dosyasını SQL Editor'de çalıştırın.
2. GitHub deposu oluşturup bu klasörü yükleyin; Netlify'de GitHub üzerinden bağlayın.
3. Netlify Environment Variables bölümünde `.env.example` değişkenlerini tanımlayın.
4. ADMIN_PASSWORD için yeni ve benzersiz parola, SESSION_SECRET için uzun rastgele değer belirleyin.
5. Deploy edin. Netlify Drop, Functions gerektiren bu projeyi tek başına çalıştırmaz.

Service role anahtarını public klasörüne koymayın. EFT ödemesi otomatik doğrulanmaz; banka hareketi satıcı tarafından kontrol edilmelidir. Siparişler panelde görünür; bu sürüm e-posta bildirimi göndermez. Ürün görselleri panelde görsel bağlantısı girilerek eklenir.
